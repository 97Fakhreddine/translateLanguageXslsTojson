const { runCreateJson } = require('./script');

runCreateJson();