const { runCreateSheet } = require('./script');

runCreateSheet();